﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfProjectTestApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OctalClear_Click(object sender, RoutedEventArgs e)
        {
            OctalOctal.Clear();
            OctalBinary.Clear();
            OctalDecimal.Clear();
            OctalHexadecimal.Clear();
        }

        private void OctalConvert_Click(object sender, RoutedEventArgs e)
        {
            int o1 = Convert.ToInt16(OctalOctal.Text);
            Octal.DecimaltoOctal(o1);
            o1 = Convert.ToInt32(Octal.returnDecOct);
            if (o1 == 8)
            { OctalOctal.Text += "    ERROR!!!!   The number you typed is not an octal number."; }
            else
            {
                Binary.ToBinary(o1);
                OctalBinary.Text = Binary.returnBinary;
                Decimal.ToDecimal(o1);
                OctalDecimal.Text = Decimal.returnDecimal;
                Hexadecimal.ToHexadecimal(o1);
                OctalHexadecimal.Text = Hexadecimal.returnHex;
            }
            //OctalDebug.Text = Convert.ToString(o1);
        }

        private void BinaryConvert_Click(object sender, RoutedEventArgs e)
        {
            string o1 = Convert.ToString(BinaryBinary.Text);
            Decimal.BinaryToDecimal(o1);
            int b1 = Convert.ToInt32(Decimal.returnDecimal);

            Octal.ToOctal(b1);
            BinaryOctal.Text = Octal.returnOctal;
            Decimal.ToDecimal(b1);
            BinaryDecimal.Text = Decimal.returnDecimal;
            Hexadecimal.ToHexadecimal(b1);
            BinaryHexadecimal.Text = Hexadecimal.returnHex;
        }

        private void BinaryClear_Click(object sender, RoutedEventArgs e)
        {
            BinaryOctal.Clear();
            BinaryBinary.Clear();
            BinaryDecimal.Clear();
            BinaryHexadecimal.Clear();
        }
        private void DecimalConvert_Click(object sender, RoutedEventArgs e)
        {
            int o1 = Convert.ToInt16(DecimalDecimal.Text);
            string s1 = DecimalDecimal.Text;
            Binary.ToBinary(o1);
            DecimalBinary.Text = Binary.returnBinary;
            Octal.ToOctal(o1);
            DecimalOctal.Text = Octal.returnOctal;
            Hexadecimal.ToHexadecimal(o1);
            DecimalHexadecimal.Text = Hexadecimal.returnHex;

        }

        private void DecimalClear_Click(object sender, RoutedEventArgs e)
        {
            DecimalOctal.Clear();
            DecimalBinary.Clear();
            DecimalDecimal.Clear();
            DecimalHexadecimal.Clear();
        }
        private void HexadecimalConvert_Click(object sender, RoutedEventArgs e)
        {
            string s1 = HexadecimalHexadecimal.Text;
            Decimal.HexToDecimal(s1);
            int o1 = Convert.ToInt16(Decimal.returnDecimal);
            Binary.ToBinary(o1);
            HexadecimalBinary.Text = Binary.returnBinary;
            Octal.ToOctal(o1);
            HexadecimalOctal.Text = Octal.returnOctal;
            Decimal.ToDecimal(o1);
            HexadecimalDecimal.Text = Decimal.returnDecimal;
        }

        private void HexadecimalClear_Click(object sender, RoutedEventArgs e)
        {
            HexadecimalOctal.Clear();
            HexadecimalBinary.Clear();
            HexadecimalDecimal.Clear();
            HexadecimalHexadecimal.Clear();
        }
    }
}
