﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfProjectTestApp
{
    class Binary
    {
        public static string returnBinary { get; private set; }

        public static void ToBinary(int input)
        {
            returnBinary = Convert.ToString(input, 2);
        }

        
    }
}
